import{W as n}from"./index-6ztGCuqF.js";class r extends n{async enable(e){}async disable(e){}}export{r as SafeAreaWeb};
//# sourceMappingURL=web-BSapx5Rp.js.map
